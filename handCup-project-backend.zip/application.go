package main

import "handCup-project-backend/api"

func main() {
	api.Run()
}
